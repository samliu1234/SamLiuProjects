// Sam Liu
// Blackjack
// June 19, 2020
// Version 1.0

import arc.*;
import java.awt.*;
import java.awt.image.*;

public class sam_liu_blackjack_final {
	
	// initialize public static variables that can be accessed in other methods outside the main class
	
	// variable representing main menu choice
	public static String strMainMenuChoice;
	
	// reusable counter variables
	public static int intCounter;
	public static int intCounter2;
	
	// these variables keep track of which index the array is on
	// intIndexOfDeck indicates how many cards have been taken from the deck
	// intIndexOfPlayer and intIndexOfDealer indicate how many cards the player and dealer have respectively in their hands
	public static int intIndexOfDeck;
	public static int intIndexOfPlayer;
	public static int intIndexOfDealer;
	
	// variable storing the user's bet
	public static double dblUserBet;
	
	// variable storing user's reward (how much money they get back)
	public static double dblUserReward;
	
	// variable storing the string version of a card when it's drawn
	public static String strNewCard;
	
	
	// main method
	public static void main(String[] args) {
		
		// create console with a name of "Blackjack," a width of 1000, and a height of 675
		Console con = new Console("Blackjack", 1000, 675);
		
		// initialize variables that are limited to the scope of the main method
		
		// deck of cards
		int[][] intDeck;
		
		// player's variables
		// player's hand
		int[][] intPlayer;
		intPlayer = new int[5][2];
		// player's total
		int intPlayerTotal;
		intPlayerTotal = 0;
		// variable storing whether user wants to hit or stay
		String strHitOrStay;
		strHitOrStay = "";
		
		// dealer's variables
		// dealer's hand
		int[][] intDealer;
		intDealer = new int[5][2];
		// dealer's total
		int intDealerTotal;
		intDealerTotal = 0;
		
		// variable storing whether user wants to play again
		String strPlayAgain;
		strPlayAgain = "";
		
		// variable storing user's money
		double dblUserMoney;
		// user starts with $1000
		dblUserMoney = 1000;
		
		// variable storing user's name
		String strName;
		
		// these are the variables used to obtain the name and score of each player from the high scores file (during text input)
		String strUserName;
		double dblUserScore;
		
		// variable for user to return to home screen
		String strReturn;
		
		
		// displays intro screen
		companyLogo(con);
		con.sleep(0000); // *change*
		con.clear();
		con.sleep(50);
		
		// make logo flash three times
		for (intCounter = 0; intCounter < 0; intCounter++) { // *change*
			
			companyLogo(con);
			con.sleep(400);	
			con.clear();
			con.sleep(50);
			
		}
		
		// set strMainMenuChoice to blank so that the while loop can run
		strMainMenuChoice = "";
		
		// game continues to run until user decides to quit
		while (!strMainMenuChoice.equalsIgnoreCase("q")) {
			
			// the following if statement ensures that the main menu is skipped if the user is playing again
			// instead, the game is started immediately
			if (!strPlayAgain.equalsIgnoreCase("y")) {
				
				// access main menu
				strMainMenuChoice = mainMenu(con); 
				
				// if user types "stronger together", they start with 500 extra dollars
				if (strMainMenuChoice.equalsIgnoreCase("p stronger together")) {
					
					dblUserMoney += 500;
					
				}
				
			}
			
			
			// reset the strPlayAgain value 
			strPlayAgain = "";
		
			// if the user chooses to play
			if (strMainMenuChoice.equalsIgnoreCase("p") || strMainMenuChoice.equalsIgnoreCase("p stronger together")) {
				
				// clear the home screen
				con.clear();
				
				// show user how much money they have
				con.println("You have $" + dblUserMoney);
				
				// ask and record user bet 
				con.println("\nWhat is your bet?");
				dblUserBet = con.readDouble();
				
				// subtract bet from the user's money
				dblUserMoney -= dblUserBet;
				
				// debug message checking if dblUserMoney is correct
				System.out.println("The user has $" + dblUserMoney + " left");
				
				// clear the betting screen
				con.clear();
				
				// create a shuffled array of cards
				intDeck = newShuffledDeck();
				
				// deal two cards to player; add to the player's hand
				for (intCounter = 0; intCounter < 2; intCounter++) {
					
					// when intCounter2 = 0, the card value is added; when intCounter2 = 1, the card suit is added
					for (intCounter2 = 0; intCounter2 < 2; intCounter2++) {
							
						intPlayer[intCounter][intCounter2] = intDeck[intCounter][intCounter2];
						
					}
					
				}
				
				// deal one card to dealer; add to the dealer's hand
				// when intCounter = 0, the card value is added; when intCounter = 1, the card suit is added
				for (intCounter = 0; intCounter < 2; intCounter++) {
					
					intDealer[0][intCounter] = intDeck[2][intCounter];
					
				}
				
				// add card to dealer's total
				// if dealer's card is an A, add 11 (because there's no chance of the total exceeding 21 on the first turn)
				if (intDealer[0][0] == 1) {
					
					intDealerTotal += 11;
				
				// if dealer's card is a jack, queen, or king, add 10
				} else if (intDealer[0][0] == 11 || intDealer[0][0] == 12 || intDealer[0][0] == 13) {
					
					intDealerTotal += 10;
				
				// otherwise, add the card value
				} else {
					
					intDealerTotal += intDealer[0][0];
					
				}
				
				// debug message checking the dealer's total
				System.out.println("The dealer's total is " + intDealerTotal);
				
				// set the index of the deck to be 3
				// So, the next time a card is drawn from the deck, it will be from index 3
				intIndexOfDeck = 3;
				
				// set the index of the player and dealer hands to 2 and 1 respectively
				// So, the next time a card is added to one of the hands, it will be at the specified index
				intIndexOfPlayer = 2;
				intIndexOfDealer = 1;
				
				// show player and dealer hands
				con.println("Your hand:                                                Dealer's hand:");
				makeHand(intPlayer, con);
				makeHand(intDealer, con);
				con.println("\n\n\n\n\n\n");
				
				// add both of the player's cards to the player's total using the addToTotal function
				for (intCounter = 0; intCounter < 2; intCounter++) {
					
					intPlayerTotal += addToTotal(intPlayer[intCounter][0], con);
					
				}
				
				// debug message checking the player's total after the first two cards
				System.out.println("The player's total after the first two cards is " + intPlayerTotal);
				
				// if player total is 21 after the first two cards
				if (intPlayerTotal == 21) {
					
					// triple the user's bet, then end the game (skips to end of loop)
					con.println("\nYou have obtained a total of 21 in the first two turns. For such a great feat, \nyou will be returned three times your bet: $" + 3 * dblUserBet);
					dblUserReward = 3 * dblUserBet;
					con.sleep(6000);
				
				// if the player's total is less than or greater than 21 after the first two cards
				} else {
					
					// if player's total is less than 21, ask if user wants to hit or stay
					// if the player's total is greater than 21, the program skips past the following for loop
					if (intPlayerTotal < 21) {
						con.println("\nDo you want to (h)it or (s)tay?");
						strHitOrStay = con.readLine();
						
						// if the player chooses to hit and his/her total is less than or equal to 21	
						while (strHitOrStay.equalsIgnoreCase("h") && intPlayerTotal <= 21) {
						
							// draw a new card and add it to the player's hand
							for (intCounter = 0; intCounter < 2; intCounter++) {
								
								intPlayer[intIndexOfPlayer][intCounter] = intDeck[intIndexOfDeck][intCounter];
								
							}
							
							// add card to player's hand
							// intPlayer[intIndexOfPlayer][0/1] obtains the appropriate card suit or number to be used
							// using 125 * intIntIndexOfPlayer as the x-value of the card image prevents overlap and creates space between adjacent cards
							BufferedImage card;
							card = con.loadImage("card" + intPlayer[intIndexOfPlayer][1] + "-" + intPlayer[intIndexOfPlayer][0] + ".png");
							con.drawImage(card, 125 * intIndexOfPlayer - 1, 30);
							con.repaint();
							
							// print card
							strNewCard = printCard(intPlayer[intIndexOfPlayer][0], intPlayer[intIndexOfPlayer][1], con);
							con.println("Your new card is " + strNewCard);
							
							// add card value to player total
							intPlayerTotal += addToTotal(intPlayer[intIndexOfPlayer][0], con);
							
							// debug message checking the intIndexOfPlayer 
							System.out.println("intIndexOfPlayer: " + intIndexOfPlayer);
							
							// increment the player and deck indices
							intIndexOfPlayer++;
							intIndexOfDeck++;
							
							// if the user has five cards without busting, skip the rest of the loop with the break statement
							if (intPlayerTotal <= 21 && intIndexOfPlayer == 5) {
								
								// the user receives quadruple their bet
								con.sleep(1000);
								con.println("\nFor having five cards and not busting, you will receive quadruple your bet: \n$" + 4 * dblUserBet);
								dblUserReward = 4 * dblUserBet;
								con.sleep(5000);
								break;
								
							}
							
							// only ask the player if they want to hit or stay again if their total is less than or equal to 21
							// if the player's total is greater than 21, then the player has busted and the question isn't asked
							if (intPlayerTotal <= 21) {
								
								con.println("\nDo you want to (h)it or (s)tay?");
								strHitOrStay = con.readLine();
								
							}
							
						
						} 
						
						// debug message checking player total after hit or stay
						System.out.println("The player's total after hit or stay is " + intPlayerTotal);
						
					}
					
					// if the player's total is greater than 21, they have busted, they lose
					if (intPlayerTotal > 21) {
						
						con.sleep(1000);
						con.println("\nYou have busted with a total of " + intPlayerTotal + ". You have lost your bet of $" + dblUserBet + ". \nGaming is ending...");
						dblUserReward = 0;
						
						// let user read the statement for 4.5 seconds
						con.sleep(4500);
					
					// if the player's total is less than or equal to 21, the player has decided to stay, continue to the dealer's turn
					} else {
						
						// if the player has not gotten five cards without busting, continue to the dealer's turn
						// if the player has gotten five cards without busting, no instructions are specified, so skip the following if statement
						if (intIndexOfPlayer < 5) {
							
							con.println("\nYou have decided to stay with a total of " + intPlayerTotal + ". Proceeding to dealer's turn...");
							
							con.sleep(3000);
							con.clear();
							
							// reset the background to black
							con.setBackgroundColor(Color.BLACK);
							// proceed to dealer's turn
							intDealerTotal = dealerTurn(intDealerTotal, intDealer, intDeck, con);
							
							// after the dealer's turn, compare the totals of the user and dealer
							comparison(intPlayerTotal, intDealerTotal, con);
							
						}
						
					}
					
				}
				
				// clear the screen
				con.clear();
				
				// reset the background
				con.setBackgroundColor(Color.BLACK);
				
				// calculate how much money the user has left after the game
				dblUserMoney += dblUserReward;
				
				// debug message checking how much money the user has left
				System.out.println("The user has " + dblUserMoney + " left");
				
				// reset totals
				intPlayerTotal = 0;
				intDealerTotal = 0;
				
				// reset user and dealer hand arrays
				for (intCounter = 0; intCounter < 5; intCounter++) {
					
					for (intCounter2 = 0; intCounter2 < 2; intCounter2++) {
						
						intPlayer[intCounter][intCounter2] = 0;
						intDealer[intCounter][intCounter2] = 0;
						
					}
					
				} 
				
				// if user has no money
				if (dblUserMoney == 0) {
					
					// tell the user they have no money, ask for their name
					con.println("You have run out of money.");
					con.println("\nThanks for playing! Before you go, we need to put you in the high scores! What’s \nyour name?");
					strName = con.readLine();
					
					// add user to high score
					addHighScore(strName, dblUserMoney);
					
					// the program reaches the end of the loop, which brings the user back to the main menu
					con.println("\nYou have been successfully added to the high scores. Returning to main menu...");
					con.sleep(2000);
					
					// reset money to 1000
					dblUserMoney = 1000;
				
				// if user has money left	
				} else {
				
					// ask if user wants to play again
					con.println("Would you like to play again? (y)es or (n)o?");
					strPlayAgain = con.readLine();
					
					// if user wants to play again
					if (strPlayAgain.equalsIgnoreCase("y")) {
						
						con.println("\nOkay, restarting...");
						con.sleep(1500);
						
						// since the user didn't have a chance to change their main menu decision, it is still p, so the game will rerun
						// also, strPlayAgain is "y," so the main menu will not reappear
					
					// if user does not want to play again	
					} else {
						
						// ask for user's name
						con.println("\nThanks for playing! Before you go, we need to put you in the high scores! What’s \nyour name?");
						strName = con.readLine();
						
						// add user to high score
						addHighScore(strName, dblUserMoney);
						
						// the program reaches the end of the loop, which brings the user back to the main menu
						con.println("\nYou have been successfully added to the high scores. Returning to main menu...");
						con.sleep(2000);
						
						// reset money to 1000
						dblUserMoney = 1000;
						
						// since the user didn't have a chance to change their main menu decision, it is still p, so the game will rerun, starting at the main menu
	
					}
				
				}
			
			// if the user needs help	
			} else if (strMainMenuChoice.equalsIgnoreCase("h")) {
				
				// clear the main menu
				con.clear();
				
				// create help image
				BufferedImage help;
				help = con.loadImage("helpscreen.png");
				con.drawImage(help, 0, 0);
				con.repaint();
				
				// if the user types anything, the text will be read, then the loop will restart (goes back to main menu)
				strReturn = con.readLine();
				
			
			// if the user wants to view the high scores
			} else if (strMainMenuChoice.equalsIgnoreCase("v")) {
				
				// clear the main menu
				con.clear();
				
				// set the background color of the console to the background color of the logo
				con.setBackgroundColor(Color.decode("#04040F"));
				
				// create an image for the "High Scores" logo
				BufferedImage logo;
				logo = con.loadImage("highScoreLogo.png");
				con.drawImage(logo, 625, 0);
				con.repaint();
				
				// tell the user to type anything to return to the home screen
				con.println("\nType anything to return to the home screen\n");
				
				// headings
				con.println("  Name                               Score\n");
				
				// open high scores file
				TextInputFile highScoresFile = new TextInputFile("highscores.txt");
				
				// while the end of file hasn't been reached, continue to read
				while (highScoresFile.eof() == false) {
					
					// read name and score
					strUserName = highScoresFile.readLine() + "                                   ";
					dblUserScore = highScoresFile.readDouble();
					
					// print name and score
					// the substring trick showed by the great Mr. Cadawas himself ensures all the scores are aligned
					con.println("  " + strUserName.substring(0, 35) + dblUserScore);
					
				}
				
				// close the file
				highScoresFile.close();
				con.println("");
				
				// if the user types anything, the text will be read, then the loop will restart (goes back to main menu)
				strReturn = con.readLine();
				
			// if user wants to quit
			} else if (strMainMenuChoice.equalsIgnoreCase("q")) {
				
				// close the console
				con.closeConsole();
			
			// if user wants to access secret screen	
			} else {
				
				// close the main menu
				con.clear();
				
				// set the background color to white
				con.setBackgroundColor(Color.WHITE);
				
				// create the image containing the joke
				BufferedImage joke;
				joke = con.loadImage("joke.png");
				con.drawImage(joke, 0, 0);
				con.repaint();
				
				// change the font color to black so the text is readable in the white background
				con.setTextColor(Color.BLACK);
				
				// if the user types anything, the text will be read, then the loop will restart (goes back to main menu)
				strReturn = con.readLine();
				
			}
			
		}
		
	}
	
	// method that prints the company logo
	public static void companyLogo(Console con) {
		
		con.println("\n\n\n                         G A E T           P O");
		con.println("                       U Q P F G L         I N");
		con.println("                     O R         F N       F C");
		con.println("                     I Y L                 T U");
		con.println("                     U P                   I L");
		con.println("                     M L I                 R Z");
		con.println("                       K Q V               Q E");
		con.println("                           U T K           Y Q");
		con.println("                             B C P         P L");
		con.println("                               L U T       H J");
		con.println("                                 R V Z     T V");
		con.println("                                   P I     O P");
		con.println("                                   O Q     E W");
		con.println("                    Y V            Q N     N L");
		con.println("                     W Y         A S       I Q");
		con.println("                       T R R P L I         S T L P Q U V R T K");
		con.println("                         L Q R T           B H V K A S L A J O");
		con.println("\n\n                    SL Entertainment presents ... Blackjack!");
		
	}
	
	// method that brings the user to the main menu
	public static String mainMenu(Console con) {
		
		// reset the main menu to its default properties (because they may have been changed after viewing other screens)
		con.clear();
		con.setBackgroundColor(Color.BLACK);
		con.setTextColor(Color.WHITE);
		
		// user's choice that will be returned
		String strChoice;
		
		// logo
		con.println("\n                                   Blackjack");
		con.println("\n                                     U R S L M T S T I U V");
		con.println("                                     U                   U");
		con.println("                              G      N                   N");
		con.println("                       A             A                   A");
		con.println("                J                    Z    G T F  L       Z");
		con.println("                                     Y    U      O       Y");
		con.println("                 U                   N    K N M  R       N");
		con.println("                                     P        J  J       P");
		con.println("                  K                  K    P U I  T N Z   K");
		con.println("                                     Z                   Z");
		con.println("                   V                 Q                   Q");
		con.println("                                     W                   W");
		con.println("                    A                N                   N");
		con.println("                                     P R S L M T S T I U V");
		con.println("                     S              N");
		con.println("                             Y");
		con.println("                      G");
		
		// options
		con.println("\n                             (P)lay");
		con.println("                             (H)elp");
		con.println("                             (V)iew high scores");
		con.println("                             (Q)uit");
		
		// ask for and record the user's decision
		con.print("\n                        Choose one of the above options: ");
		strChoice = con.readLine();
		
		// return the choice
		return strChoice;
		
	}
	
	// method that shuffles the deck
	public static int[][] newShuffledDeck() {
		
		// create the array that will be returned
		int[][] intShuffledDeck;
		intShuffledDeck = new int[52][3];
		
		// random number variable
		int intRandom;
		
		// fills the array
		// repeat four times
		for (intCounter = 0; intCounter < 4; intCounter++) {
			
			// repeat 13 times
			for (intCounter2 = 0; intCounter2 < 13; intCounter2++) {
				
				// creates the card numbers
				// intCounter * 13 + intCounter2 yields the indices from 0 to 51. intCounter2 + 1 adds numbers from 1 to 13 four times
				intShuffledDeck[intCounter * 13 + intCounter2][0] = intCounter2 + 1;
				
				// creates the card suits
				// intCounter * 13 + intCounter2 yields the indices from 0 to 51. intCounter + 1 adds numbers from 1 to 4 thirteen times
				intShuffledDeck[intCounter * 13 + intCounter2][1] = intCounter + 1;
				
				// generates random number from 1 to 100
				intRandom = (int)(Math.random() * 100 + 1);
				
				// intCounter * 13 + intCounter2 yields the indices from 0 to 51. The random number is set to the third column
				intShuffledDeck[intCounter * 13 + intCounter2][2] = intRandom;
				
			}
			
		}
		
		// bubble sort the array in increasing order by the random number
		// create variables
		int intTemp;
		int intTop;
		int intBottom;
		// determines the number of fixes the sorting algorithim makes
		int intFixes;
		intFixes = 0;
		// determines whether the array has been sorted
		boolean boolSorted;
		boolSorted = false;
		
		// while the array is not completely sorted
		while (boolSorted == false) {
			
			// runs 51 times; checks every adjacent pair
			for (intCounter = 0; intCounter < 51; intCounter++) {
				
				// assigns adjacent values to the top and bottom variables 
				intTop = intShuffledDeck[intCounter][2];
				intBottom = intShuffledDeck[intCounter + 1][2];
				
				// if the top number is greater than the bottom number, then swap the values
				if (intTop > intBottom) {
					
					// swaps in the third column
					// assigns the top number to the temporary variable
					intTemp = intShuffledDeck[intCounter][2];
					// assigns the bottom number to the top number
					intShuffledDeck[intCounter][2] = intShuffledDeck[intCounter + 1][2];
					// assigns the temporary variable (which stores the top value) to the bottom number 
					intShuffledDeck[intCounter + 1][2] = intTemp;
					
					// swaps in the second column
					intTemp = intShuffledDeck[intCounter][1];
					intShuffledDeck[intCounter][1] = intShuffledDeck[intCounter + 1][1];
					intShuffledDeck[intCounter + 1][1] = intTemp;
					
					// swaps in the first column
					intTemp = intShuffledDeck[intCounter][0];
					intShuffledDeck[intCounter][0] = intShuffledDeck[intCounter + 1][0];
					intShuffledDeck[intCounter + 1][0] = intTemp;
					
					// every time a swap is made, increment the number of fixes
					intFixes++;
					
				}
			
			}
			
			// if the number of fixes is 0, that means the array is sorted; stop the loop
			if (intFixes == 0) {
				
				boolSorted = true;
			
			// otherwise, reset intFixes and restart the sorting procedure	
			} else {
				
				intFixes = 0;
				
			}
			
		}
			
		// returns the sorted array of cards
		return intShuffledDeck;
		
	}
	
	// method that visually displays the player's or dealer's hand
	// note that this method is only used for displaying the player's first two cards or the dealer's first card
	// there is too much variability in the other scenarios (in terms of location), so the code is individually programmed
	public static void makeHand(int[][] intHand, Console con) {
		
		// create variable to determine how many cards are in the hand
		int intHandSize;
		intHandSize = 0;
		
		// for loop determining how many cards the user has
		// for loop is run for every row of the array (5 times)
		for (intCounter = 0; intCounter < 5; intCounter++) {
			
			// if an item in an integer array has not been initialized, the item will be set to 0
			if (intHand[intCounter][0] == 0) { 
				
				// if the item is set to 0, set the size of the hand, and break out of the for loop
				// intHandSize = intCounter because intCounter represents the index at which the value is first 0, which is the size of the hand
				intHandSize = intCounter;
				break;
				
			}
			
		}
		
		// initialize the card number and suit variables
		int intCardNumber;
		int intCardSuit;
		
		// for every card in the hand
		for (intCounter = 0; intCounter < intHandSize; intCounter++) {
			
			// assign the card number and suit to their respective variables
			intCardNumber = intHand[intCounter][0];
			intCardSuit = intHand[intCounter][1];
			
			// if the hand size is 1, it must be the dealer's hand, so position the card appropriately
			if (intHandSize == 1) {
			
				BufferedImage card;
				card = con.loadImage("card" + intCardSuit + "-" + intCardNumber + ".png");
				con.drawImage(card, 695, 30);
				con.repaint();
			
			// if the hand size isn't 1, it must be the player's hand, so position the cards appropriately
			// Since the width of each image is 100, 125 * intCounter prevents overlap between the cards and even adds a space between them
			} else {
				
				BufferedImage card;
				card = con.loadImage("card" + intCardSuit + "-" + intCardNumber + ".png");
				con.drawImage(card, 125 * intCounter, 30);
				con.repaint();
				
			}
			
		}
		
	}
	
	// method that adds a card to the total
	public static int addToTotal(int intCard, Console con) {
		
		// initialize the return variable
		int intReturn;
		
		// if the card is an ace
		if (intCard == 1) {
			
			// ask the user if they want a 1 or 11, return the value they choose
			con.println("\nDo you want your ace to be a 1 or 11?");
			intReturn = con.readInt();
		
		// if the card is a jack, queen, or king, return 10	
		} else if (intCard == 11 || intCard == 12 || intCard == 13) {
			
			intReturn = 10;
		
		// otherwise, return the numeric value of the card
		} else {
			
			intReturn = intCard;
			
		}
		
		// return integer value
		return intReturn;
		
	}

	// method that prints a card that was drawn
	public static String printCard(int intCard, int intSuit, Console con) {
		
		// make variable to be returned
		String strHand;
		
		// if card number is 1, add A
		if (intCard == 1) {
			
			strHand = "A";
		
		// if card number is 11, add J
		} else if (intCard == 11) {
			
			strHand = "J";
		
		// if card number is 12, add Q
		} else if (intCard == 12) {
			
			strHand = "Q";
		
		// if card number is 13, add K
		} else if (intCard == 13) {
			
			strHand = "K";
		
		// otherwise, add the card number
		} else {
			
			strHand = String.valueOf(intCard);
			
		}
	
		// if suit number is 1, add diamonds
		if (intSuit == 1) {
			
			strHand += " of diamonds";
		
		// if suit number is 2, add clubs	
		} else if (intSuit == 2) {
			
			strHand += " of clubs";
		
		// if suit number is 3, add hearts		
		} else if (intSuit == 3) {
			
			strHand += " of hearts";
		
		// if suit number is 4, add spades		
		} else {
			
			strHand += " of spades";
			
		}
		
		// return string version of card
		return strHand;
		
	}

	// method that runs the dealer's turn
	public static int dealerTurn(int intDealerTotal, int[][] intDealerCards, int[][] intDeck, Console con) {
		
		// make and visually show the dealer's hand
		con.println("Dealer's hand: ");
		BufferedImage firstCard;
		firstCard = con.loadImage("card" + intDealerCards[0][1] + "-" + intDealerCards[0][0] + ".png");
		con.drawImage(firstCard, 0, 30);
		con.repaint();
		
		// these spaces span the height of a card
		con.println("\n\n\n\n\n\n\n");
		
		// if the dealer got an A as the first card, print that the dealer has chosen 11 (because can't exceed 21 on the first turn)
		if (intDealerTotal == 11) {
			
			con.println("The dealer has chosen for the A to be an 11.");
			con.sleep(1500);
		
		// if the dealer did not get an A, let the player look at the dealer's hand for 1.5 seconds
		} else {
			
			con.sleep(1500);
			
		}
		
		// initialize intCounter2 = 1
		// intCounter2 will be incremented after every hit
		// If the dealer hits, the new card will be placed at 125 * intCounter2, preventing overlap between cards
		intCounter2 = 1;
		
		// while the dealer's total is less than 17, continue to hit
		while (intDealerTotal < 17) {
			
			// draw a new card 
			for (intCounter = 0; intCounter < 2; intCounter++) {
							
				intDealerCards[intIndexOfDealer][intCounter] = intDeck[intIndexOfDeck][intCounter];
							
			}
			
			// create and display card under dealer's hand
			BufferedImage card;
			card = con.loadImage("card" + intDealerCards[intIndexOfDealer][1] + "-" + intDealerCards[intIndexOfDealer][0] + ".png");
			con.drawImage(card, 125 * intCounter2, 30);
			con.repaint();
			
			// print card
			strNewCard = printCard(intDealerCards[intIndexOfDealer][0], intDealerCards[intIndexOfDealer][1], con);
			con.println("The dealer hits and gets a " + strNewCard);
			
			// if card is an A, choose whether the value of A is 1 or 11
			if (intDealerCards[intIndexOfDealer][0] == 1) {
				
				// if the dealer total is less than or equal to 10, choose 11 because the dealer won't bust
				if (intDealerTotal <= 10) {
					
					con.println("The dealer has chosen the A to be an 11");
					intDealerTotal += 11;
				
				// if the dealer total is greater than 10, choose 1 because the dealer will bust	
				} else {
					
					con.println("The dealer has chosen the A to be a 1");
					intDealerTotal += 1;
					
				}
				
				con.sleep(1000);
			
			// if the card is a jack, queen, or king, add 10 to the dealer's total
			} else if (intDealerCards[intIndexOfDealer][0] == 11 || intDealerCards[intIndexOfDealer][0] == 12 || intDealerCards[intIndexOfDealer][0] == 13) {
				
				intDealerTotal += 10;
			
			// otherwise, add the card number to the dealer's total
			} else {
				
				intDealerTotal += intDealerCards[intIndexOfDealer][0];
				
			}
			
			con.sleep(1500);
			
			// increment intCounter2
			intCounter2++;
			
			// increment the dealer and deck indices
			intIndexOfDealer++;
			intIndexOfDeck++;
			
		}
		
		// if the dealer total is greater than 21, print that the dealer has busted
		if (intDealerTotal > 21) {
			
			// print the total with which the dealer has busted
			con.println("\nThe dealer has busted with a total of " + intDealerTotal + ".");
		
		// if the dealer total is less than or equal to 21, print that the dealer has decided to stay
		} else {
			
			// print the total with which the dealer has decided to stay
			con.println("\nThe dealer has decided to stay with a total of " + intDealerTotal + ".");
		
		}
		
		con.sleep(2000);
		
		// return dealer total
		return intDealerTotal;
		
	}
	
	// method that compares the player and dealer totals
	public static void comparison(int intPlayerTotal, int intDealerTotal, Console con) {
		// print totals to screen
		con.println("\nYour total: " + intPlayerTotal);
		con.println("Dealer total: " + intDealerTotal);
		
		con.sleep(1500);
		
		// note that if the player had busted, this method wouldn't be reachable
		// therefore, the player must not have busted
		
		// if dealer busted
		if (intDealerTotal > 21) {
			
			// the player will redeive double their bet
			con.println("\nThe dealer has busted. You will receive double your bet: $" + 2 * dblUserBet + ".");
			con.println("Gaming is ending...");
			dblUserReward = 2 * dblUserBet;
		
		// if the above if statement is passed, that means both the player and dealer did not bust
		// if player total is equal to dealer total
		} else if (intPlayerTotal == intDealerTotal) {
			
			// the player's bet will be returned to them
			con.println("\nYou have tied with the dealer. Your bet of $" + dblUserBet + " will be returned to you.");
			con.println("Gaming is ending...");
			dblUserReward = dblUserBet;
		
		// if player total is greater than dealer total
		} else if (intPlayerTotal > intDealerTotal) {
			
			// the player will redeive double their bet
			con.println("\nYou have won! You will receive double your bet: $" + 2 * dblUserBet + ".");
			con.println("Gaming is ending...");
			dblUserReward = 2 * dblUserBet;
		
		// if player total is less than dealer total
		} else {
			
			// the player will lose their bet
			con.println("\nYou have lost. You have lost your bet of $" + dblUserBet + ".");
			con.println("Gaming is ending...");
			dblUserReward = 0;
		
		}
		
		con.sleep(4000);
		
	}
	
	// method that adds player to high scores list
	public static void addHighScore(String strUserName, double dblUserMoney) {
		
		// open high scores file
		TextOutputFile highScoreFile = new TextOutputFile("highscores.txt", true);
		
		// add user's name and money to high scores file
		highScoreFile.println(strUserName);
		highScoreFile.println(dblUserMoney);
		
		// close high scores file
		highScoreFile.close();
		
	}
	
}
